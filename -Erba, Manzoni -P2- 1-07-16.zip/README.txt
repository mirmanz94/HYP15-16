Used Template: https://html5up.net/verti
Used Framework: Ajax, Json, Jquery
Other Information: We used "(not clickable)" to visualy display unclickable buttons. The Group Telecom Italia isn't clickable as said in project delivery document.